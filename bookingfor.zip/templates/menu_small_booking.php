			<div >
				<ul class="bfi-menu-small bfi-menu-booking">
						<li><a class="bfi-btn bfi-alternative3"><?php _e('Your search', 'bfi'); ?></a></li>
						<li><a class="bfi-btn bfi-alternative3"><?php _e('Extra services', 'bfi'); ?></a></li>
						<li><a class="bfi-btn bfi-alternative3"><?php _e('Insert your data', 'bfi'); ?></a></li>
						<li><a class="bfi-btn bfi-alternative3"><?php _e('Confirm booking', 'bfi'); ?></a></li>
				</ul>
			</div>
