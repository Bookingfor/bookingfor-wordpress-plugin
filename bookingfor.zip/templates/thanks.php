<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div class="bfi-content">	
<br />
<h2><?php _e('Thank you for having chosen us.', 'bfi') ?></h2>
<br />
<br />
</div>	
